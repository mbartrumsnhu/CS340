from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Connection variables
        USER = 'aacuser'
        PASS = 'password'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32157
        DB = 'AAC'
        COL = 'animals'
        
        # Initialize MongoClient
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # Create method (C in CRUD)
    def create(self, data):
        """
        Inserts a document into the MongoDB collection.
        :param data: Dictionary containing the document to insert.
        :return: True if the insert is successful, otherwise False.
        """
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"An error occurred while inserting: {e}")
                return False
        else:
            raise Exception("Nothing to save, because the data parameter is empty")

    # Read method (R in CRUD)
    def read(self, query):
        """
        Queries documents from the MongoDB collection.
        :param query: Dictionary representing the search criteria.
        :return: List of documents that match the query.
        """
        try:
            cursor = self.collection.find(query)  # Use find() to return multiple documents
            result = list(cursor)
            return result if result else []
        except Exception as e:
            print(f"An error occurred during read operation: {e}")
            return []

    # Update method (U in CRUD)
    def update(self, query, update_data, multiple=False):
        """
        Updates document(s) in the MongoDB collection.
        :param query: Dictionary representing the search criteria.
        :param update_data: Dictionary containing the fields to update.
        :param multiple: Boolean indicating whether to update one or many documents.
        :return: The number of documents updated.
        """
        if query and update_data:
            try:
                if multiple:
                    result = self.collection.update_many(query, {"$set": update_data})
                else:
                    result = self.collection.update_one(query, {"$set": update_data})
                return result.modified_count
            except Exception as e:
                print(f"An error occurred while updating: {e}")
                return 0
        else:
            raise Exception("Both query and update_data must be provided")

    # Delete method (D in CRUD)
    def delete(self, query, multiple=False):
        """
        Deletes document(s) from the MongoDB collection.
        :param query: Dictionary representing the search criteria.
        :param multiple: Boolean indicating whether to delete one or many documents.
        :return: The number of documents deleted.
        """
        if query:
            try:
                if multiple:
                    result = self.collection.delete_many(query)
                else:
                    result = self.collection.delete_one(query)
                return result.deleted_count
            except Exception as e:
                print(f"An error occurred while deleting: {e}")
                return 0
        else:
            raise Exception("Query must be provided")
